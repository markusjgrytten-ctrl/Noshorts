# NoShorts

A small Android app for GrapheneOS (works on any Android 8+) that closes
short-form video as soon as it opens:

- **YouTube Shorts** in the YouTube app: presses Back
- **Instagram Reels** in the Instagram app: presses Back
- **TikTok**: sends you to the home screen
- **Browsers** (Vanadium, Chromium, Brave, Firefox forks, DuckDuckGo):
  backs out of `youtube.com/shorts`, `instagram.com/reel`, `facebook.com/reel`, `tiktok.com`

Regular videos, feeds, search and DMs keep working. No internet permission,
no dependencies, nothing collected.

## Build the APK

**Easiest (no PC needed):** create a GitHub repo, upload this folder, open
the **Actions** tab. The included workflow builds the APK; download it from the
run's *Artifacts* section (`NoShorts-apk`).

**On a computer:** open the folder in Android Studio and press Run, or with
the Android SDK installed run `gradle assembleRelease`. The APK lands in
`app/build/outputs/apk/release/`.

## Install on GrapheneOS

1. Open the APK and allow installing from your browser/Files app when asked.
2. Open **NoShorts** and tap **Turn on blocker**.
3. Tap **NoShorts blocker** in the list. If the switch is greyed out
   ("Restricted setting"), go to **Settings → Apps → NoShorts → ⋮ →
   Allow restricted settings**, then try again.
4. Turn it on and accept.

If YouTube/Instagram run in a different user profile, install NoShorts in that
profile too.

## If something stops being blocked

Apps rename their internal view IDs now and then. The lists are at the top of
`ShortsBlockerService.kt`. To find a new ID, turn on
*Developer options → Show layout bounds* or use an app like
"Developer Assistant", open the Shorts screen, and add the ID it shows.

## Making it harder to switch off

Android lets you disable accessibility services at any time. For more
friction, enable Settings → Accessibility → shortcut off, and remove the
quick-settings toggle if you've added one.
