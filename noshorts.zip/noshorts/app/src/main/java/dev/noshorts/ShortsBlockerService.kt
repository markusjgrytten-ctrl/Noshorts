package dev.noshorts

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * Detects short-form video screens and backs out of them.
 *
 * Detection works on the view IDs / descriptions the apps expose to
 * accessibility. App updates sometimes rename these, so each target has
 * several fallbacks. Edit the lists below if something stops being caught.
 */
class ShortsBlockerService : AccessibilityService() {

    private val youtubeIds = listOf(
        "com.google.android.youtube:id/reel_recycler",
        "com.google.android.youtube:id/reel_player_page_container",
        "com.google.android.youtube:id/reel_watch_player",
        "com.google.android.youtube:id/reel_time_bar",
    )
    private val instagramIds = listOf(
        "com.instagram.android:id/clips_viewer_view_pager",
        "com.instagram.android:id/clips_viewer_container",
        "com.instagram.android:id/clips_video_container",
    )

    private val tiktokPackages = setOf(
        "com.zhiliaoapp.musically",
        "com.ss.android.ugc.trill",
        "com.ss.android.ugc.aweme",
    )

    /** Browser package -> its address-bar view ID. */
    private val browserUrlBars = mapOf(
        "app.vanadium.browser" to "app.vanadium.browser:id/url_bar",
        "org.chromium.chrome" to "org.chromium.chrome:id/url_bar",
        "com.android.chrome" to "com.android.chrome:id/url_bar",
        "com.brave.browser" to "com.brave.browser:id/url_bar",
        "org.mozilla.firefox" to "org.mozilla.firefox:id/mozac_browser_toolbar_url_view",
        "org.mozilla.fennec_fdroid" to "org.mozilla.fennec_fdroid:id/mozac_browser_toolbar_url_view",
        "org.ironfoxoss.ironfox" to "org.ironfoxoss.ironfox:id/mozac_browser_toolbar_url_view",
        "us.spotco.fennec_dos" to "us.spotco.fennec_dos:id/mozac_browser_toolbar_url_view",
        "com.duckduckgo.mobile.android" to "com.duckduckgo.mobile.android:id/omnibarTextInput",
    )
    private val blockedUrlParts = listOf(
        "youtube.com/shorts",
        "instagram.com/reel",
        "facebook.com/reel",
        "tiktok.com",
    )

    private var lastAction = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (SystemClock.uptimeMillis() - lastAction < 800) return // avoid back-spamming

        when {
            pkg == "com.google.android.youtube" && on(Prefs.YOUTUBE) ->
                if (hasAnyId(youtubeIds)) block("Shorts blocked")

            pkg == "com.instagram.android" && on(Prefs.INSTAGRAM) ->
                if (hasAnyId(instagramIds)) block("Reels blocked")

            pkg in tiktokPackages && on(Prefs.TIKTOK) ->
                blockWholeApp("TikTok blocked")

            pkg in browserUrlBars && on(Prefs.BROWSER) ->
                if (browserOnBlockedUrl(pkg)) block("Blocked in browser")
        }
    }

    private fun on(key: String) = Prefs.isOn(this, key)

    private fun hasAnyId(ids: List<String>): Boolean {
        val root = rootInActiveWindow ?: return false
        return ids.any { id ->
            root.findAccessibilityNodeInfosByViewId(id).any { it.isVisibleToUser }
        }
    }

    private fun browserOnBlockedUrl(pkg: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val bar = root.findAccessibilityNodeInfosByViewId(browserUrlBars.getValue(pkg))
            .firstOrNull() ?: return false
        if (bar.isFocused) return false // user is typing, don't interrupt
        val url = bar.text?.toString()?.lowercase() ?: return false
        return blockedUrlParts.any { url.contains(it) }
    }

    private fun block(msg: String) {
        lastAction = SystemClock.uptimeMillis()
        performGlobalAction(GLOBAL_ACTION_BACK)
        record(msg)
    }

    private fun blockWholeApp(msg: String) {
        lastAction = SystemClock.uptimeMillis()
        performGlobalAction(GLOBAL_ACTION_HOME)
        record(msg)
    }

    private fun record(msg: String) {
        Prefs.incBlocked(this)
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onInterrupt() {}
}
