package dev.noshorts

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var enableButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        col.addView(TextView(this).apply {
            text = "NoShorts"
            textSize = 28f
        })

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, pad / 2, 0, pad / 2)
        }
        col.addView(status)

        enableButton = Button(this).apply {
            text = "Open accessibility settings"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        col.addView(enableButton)

        col.addView(TextView(this).apply {
            text = "Block:"
            textSize = 18f
            setPadding(0, pad, 0, pad / 4)
        })

        for ((key, label) in Prefs.ALL) {
            col.addView(Switch(this).apply {
                text = label
                textSize = 16f
                isChecked = Prefs.isOn(this@MainActivity, key)
                setPadding(0, pad / 3, 0, pad / 3)
                setOnCheckedChangeListener { _, on -> Prefs.set(this@MainActivity, key, on) }
            })
        }

        col.addView(TextView(this).apply {
            text = "When a Shorts/Reels screen opens, NoShorts presses Back. " +
                "TikTok is sent to the home screen. Regular videos, feeds and " +
                "messages keep working.\n\nNo internet permission, no data stored " +
                "except these switches and a counter."
            setTextColor(Color.GRAY)
            setPadding(0, pad, 0, 0)
            gravity = Gravity.START
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        val enabled = serviceEnabled()
        status.text = if (enabled)
            "✅ Blocker is on · ${Prefs.blockedCount(this)} blocked so far"
        else
            "⚠️ Blocker is off. Tap below, open \"NoShorts blocker\" and turn it on."
        enableButton.text = if (enabled) "Accessibility settings" else "Turn on blocker"
    }

    private fun serviceEnabled(): Boolean {
        val me = ComponentName(this, ShortsBlockerService::class.java).flattenToString()
        val list = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return list.split(':').any { it.equals(me, ignoreCase = true) }
    }
}
