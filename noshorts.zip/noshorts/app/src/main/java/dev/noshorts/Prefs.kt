package dev.noshorts

import android.content.Context

/** Simple on/off switches, stored locally. */
object Prefs {
    const val YOUTUBE = "block_youtube_shorts"
    const val INSTAGRAM = "block_instagram_reels"
    const val TIKTOK = "block_tiktok"
    const val BROWSER = "block_browser_shorts"

    val ALL = listOf(
        YOUTUBE to "YouTube Shorts (app)",
        INSTAGRAM to "Instagram Reels (app)",
        TIKTOK to "TikTok (whole app)",
        BROWSER to "Shorts/Reels/TikTok in browsers",
    )

    private fun sp(ctx: Context) = ctx.getSharedPreferences("noshorts", Context.MODE_PRIVATE)

    fun isOn(ctx: Context, key: String) = sp(ctx).getBoolean(key, true)
    fun set(ctx: Context, key: String, on: Boolean) = sp(ctx).edit().putBoolean(key, on).apply()

    fun blockedCount(ctx: Context) = sp(ctx).getInt("blocked_count", 0)
    fun incBlocked(ctx: Context) = sp(ctx).edit().putInt("blocked_count", blockedCount(ctx) + 1).apply()
}
